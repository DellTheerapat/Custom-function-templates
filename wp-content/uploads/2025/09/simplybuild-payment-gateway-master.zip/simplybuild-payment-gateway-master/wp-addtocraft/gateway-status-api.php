<?php
/**
 * Plugin Name: Private Gateway Status API
 * Description: REST API endpoint for checking gateway status.
 * Version: 1.0
 * Author: NBJ
 */

function myplugin_rest_permissions_check( $request ) {
    // return current_user_can( 'manage_options' ); // Only admins

    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'rest_forbidden', 'You must be logged in.', [ 'status' => 401 ] );
    }

    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error( 'rest_forbidden', 'Access denied.', [ 'status' => 403 ] );
    }else{
		return current_user_can( 'manage_options' ); // Only admins
	}

}


function omise_check_gateway_connection() {
    $settings = get_option( 'woocommerce_omise_settings' );
    // $promptpay = get_option( 'woocommerce_omise_promptpay_settings' );

// 	var_dump($settings);

	if ( is_wp_error( $response ) ) {

        return [
            'connected' => false,
            'message' => 'Connection error.'
        ];

    }
	
	if (!($settings['account_id'])){

		 return [
            'connected' => false,
            'gateway' => 'omise',
            'message' => 'Missing or Invalid API Credentials.'
        ];

	}else{

		return [
            'connected' => true,
            'gateway' => 'omise',
			'sandbox' => !empty($settings['sandbox']) ? $settings['sandbox'] : 'no',
			'test_public_key' => !empty($settings['test_public_key']) ? 'active' : 'inactive',
			'test_private_key' => !empty($settings['test_private_key']) ? 'active' : 'inactive',
			'live_public_key' => !empty($settings['live_public_key']) ? 'active' : 'inactive',
			'live_private_key' => !empty($settings['live_private_key']) ? 'active' : 'inactive'
            // 'message' => 'Found API Credentials.',
        ];
	}
	
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'omise/v1', '/gateway-status', [
        'methods'  => 'GET',
        'callback' => 'omise_check_gateway_connection',
// 		 'permission_callback' => '__return_true',
		'permission_callback' => 'myplugin_rest_permissions_check',
    ] );
});

