<?php

// Set the response header to indicate that we're expecting JSON data

use ElementorPro\Data\Http_Status;

header("Content-Type: application/json");

$inputData = json_decode(file_get_contents('php://input'), true);

if ($inputData) {
    // Set up logging
    function log_message($message)
    {
        // Output to stdout (captured by Cloud Run logs)
        echo $message . "\n";
        // Optionally log to stderr
        error_log($message);
    }

    // Remote server details
    $remote_server = '162.254.36.6';            // Replace with your server address
    $remote_port = 61203;                       // SSH port, default is 22
    $username = $inputData['username'];         // Replace with your SSH username
    $password = $inputData['password'];         // Replace with your SSH password

    // Merchant payment details
    // $enabled = $inputData['enabled'];
    $sandbox = $inputData['sandbox'];

    // Live keys
    $live_public_key = $inputData['live_public_key'];
    $live_private_key = $inputData['live_private_key'];

    // Sandbox keys
    $test_public_key = $inputData['test_public_key'];
    $test_private_key = $inputData['test_private_key'];

    // Establishing the SSH connection
    $connection = ssh2_connect($remote_server, $remote_port);
    if (!$connection) {
        die('Connection failed to ' . $remote_server . ':' . $remote_port);
    }

    // Authenticate with the remote server
    if (!ssh2_auth_password($connection, $username, $password)) {
        die('Authentication with the server is invalid' . json_encode(['status' => 'error']));
    }

    // log_message("Successfully connected to remote server: $remote_server:$remote_port as user: $username");

    $commands = [
        'echo "<?php echo \'Processing your request...\'; ?>" > index.php', // Ensure the filename is correct if needed
        'cd public_html && wp option update woocommerce_omise_settings \'{"sandbox":"' . $sandbox . '", "live_public_key":"' . $live_public_key . '","live_private_key":"' . $live_private_key . '", "test_public_key":"' . $test_public_key . '","test_private_key":"' . $test_private_key . '"}\' --format=json'
    ];

    foreach ($commands as $command) {
        $output = ssh2_exec($connection, $command);

        // Optionally, fetch output (for debugging purposes)
        // stream_set_blocking($output, true);

        $output_data = stream_get_contents($output);

        if ($output_data) {
            // log_message("Command output for '$command': $output_data");
            // file_put_contents($sshLogs, print_r($output_data, true) . PHP_EOL, FILE_APPEND); // Consider Cloud Run logs instead
        }

        if ($output_data === '') {
            // log_message("Successfully executed: $command");
        } else {
            log_message("Error executing command: $command");
            log_message("Error: $output_data");
            // file_put_contents($sshLogs, print_r($output_data, true) . PHP_EOL, FILE_APPEND); // Consider Cloud Run logs instead
            echo json_encode(['status' => 'error', 'message' => 'Error executing command on remote server', 'details' => $output_data]);
            exit;
        }
    }

    ssh2_disconnect($connection);
    echo json_encode(['status' => 'success', 'message' => 'Payment Gateway settings updated successfully']);

} else {
    // If the required data is not provided in the request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON data received']);
}