<?php

# keys
wp option update woocommerce_omise_settings '{"live_public_key":"","live_private_key":"", "test_public_key":"pkey_test_62iplim0uor3fh2mqym","test_private_key":"skey_test_62ipllhjwkszon9rdzk"}' --format=json

# credit card
wp option update woocommerce_omise_promptpay_settings '{"enabled":"yes"}' --format=json

# prompt pay
wp option update woocommerce_omise_settings '{"enabled":"yes"}' --format=json

# enable disable test mode
wp option update woocommerce_omise_settings '{"sandbox":"no"}' --format=json