<?php

function myplugin_rest_permissions_check( $request ) {
    return current_user_can( 'manage_options' ); // Only admins
}


function omise_check_gateway_connection() {
    $settings = get_option( 'woocommerce_omise_settings' );

// 	var_dump($settings);

	if ( is_wp_error( $response ) ) {
        return [
            'connected' => false,
            'message' => 'Connection error.'
        ];
    }
	
	if (!($settings['account_id'])){
		 return [
            'connected' => false,
            'message' => 'Missing or Invalid API Credentials.'
        ];
	}else{
		return [
            'connected' => true,
            'message' => 'Found API Credentials.',
			'test_public_key' => !empty($settings['test_public_key']) ? 'active' : 'inactive',
			'test_private_key' => !empty($settings['test_private_key']) ? 'active' : 'inactive',
			'live_public_key' => !empty($settings['live_public_key']) ? 'active' : 'inactive',
			'live_private_key' => !empty($settings['live_private_key']) ? 'active' : 'inactive',
        ];
	}
	
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'omise/v1', '/gateway-status', [
        'methods'  => 'GET',
        'callback' => 'omise_check_gateway_connection',
// 		 'permission_callback' => '__return_true',
		'permission_callback' => 'myplugin_rest_permissions_check',
    ] );
});